/**
 * This class represents two available operators.
 * @author Kunlaya Kobunnoi
 * 
 */
public enum TableType { 
ADD, MULT 
}


