/**
 * This class represents three available operators.
 * @author Kunlaya Kobunnoi
 * 
 */
public enum TableType { 
ADD, MULT, SUB 
}
